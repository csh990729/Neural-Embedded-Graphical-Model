import numpy as np
import torch.multiprocessing as mp
import torch
from torch import nn
from torch import optim
import torch.utils.data as Data
prefix='./'


device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
print(device)

data_1 = np.loadtxt(prefix+'data_input.txt')
#print("min and max of data_1:")
#print(np.min(np.abs(data_1)))
#print(np.max(np.abs(data_1)))
print("mean of abs data_1:")
inputave = np.mean(np.abs(data_1))
print(inputave)
#data_1 /= inputave

data_2 = np.loadtxt(prefix+'data_output.txt')
#print("min and max of data_2:")
#print(np.min(np.abs(data_2)))
#print(np.max(np.abs(data_2)))
print("mean of abs data_2:")
outputave = np.mean(np.abs(data_2))
print(outputave)
data_2 /= outputave

class NNElement(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_dim, hidden_num, K):
        super().__init__()

        #self.K = torch.from_numpy(np.linalg.pinv(K)).float()
        self.K = torch.from_numpy(K).float()

        self.Li = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.Tanh()
            #nn.Softplus()
            #nn.ReLU()
            #nn.LeakyReLU(0.01)
            #nn.BatchNorm1d(hidden_dim)
        )
        
        self.Linter = torch.nn.ModuleList([])
        for i in range(hidden_num):
            self.Linter.append(nn.Linear(hidden_dim, hidden_dim))
            self.Linter.append(nn.Tanh())
            #self.Linter.append(nn.Softplus())
            #self.Linter.append(nn.ReLU())
            #self.Linter.append(nn.LeakyReLU(0.01))
            #self.Linter.append(nn.Sigmoid())
            #self.Linter.append(nn.BatchNorm1d(hidden_dim))
        
        #self.Lo1 = nn.Linear(hidden_dim, hidden_dim)
        #self.Lo2 = nn.Tanh()
        self.Lo = nn.Linear(hidden_dim, output_dim, bias=False)
        self.Lo.weight.data = nn.Parameter(self.K, requires_grad=False)

        #for m in self.modules():
        #    if isinstance(m, nn.Linear):
        #        m.weight.data.zero_()
        #        m.bias.data.zero_()

    def forward(self, x):
        x = self.Li(x)
        for layer in self.Linter:
            x = layer(x)
        #x = self.Lo1(x)
        #x = self.Lo2(x)
        out = self.Lo(x)
        return out

K0 = np.eye(8)
x = torch.from_numpy(np.concatenate((data_1[:,:4], data_2[:,4:]), axis=1)).float()
y = torch.from_numpy(data_1).float()
x, y = x.to(device), y.to(device)

model2 = NNElement(8, 8, 8, 2, K0).to(device)
model2.load_state_dict(torch.load(prefix+'trained_matrix_f2d.pth'))

#if torch.cuda.device_count() > 1:
#  print("Let's use", torch.cuda.device_count(), device)
#  model2 = nn.DataParallel(model2)

lr0 = 1e-4
lrx = 1e-5
nepochs = 2000000
decayrate = np.exp(np.log(lrx/lr0)/nepochs)
optimizer = optim.Adam(model2.parameters(), lr=lr0)
#scheduler = optim.lr_scheduler.MultiStepLR(optimizer, milestones=[50000, 150000, 200000], gamma=0.1)
scheduler = optim.lr_scheduler.ExponentialLR(optimizer, gamma=decayrate)

#loss_fn = nn.MSELoss()
loss_fn = nn.L1Loss()

for epoch in range(nepochs):
	y_ = model2(x)
	loss = loss_fn(y_, y)
	loss.backward()
	optimizer.step()
	optimizer.zero_grad()
	if epoch==0 or (epoch+1)%1000==0:
		print((epoch+1), loss.item())
	if (epoch+1)%1000 == 0:
		#torch.save(model2.module.state_dict(), prefix+'trained_matrix_f2d.pth')
		torch.save(model2.state_dict(), prefix+'trained_matrix_f2d.pth')
	scheduler.step()
