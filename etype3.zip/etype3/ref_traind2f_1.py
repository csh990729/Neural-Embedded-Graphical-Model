import numpy as np
import torch.multiprocessing as mp
import torch
from torch import nn
from torch import optim
from torch.utils.data import Dataset, DataLoader
from torch.optim.lr_scheduler import LambdaLR

prefix='./'

def circle_warmup_cosinedecay(base_lr, max_lr, warm_step=500, period=5000, decay=0.01, total_cycle=None):
    """
    Circle Warmup Cosine Decay Scheduler
    """
    def global_decay(t):
        return 1.0 - (1.0-decay)*(np.int(t/period)/(total_cycle-1)) # decay from 1.0 to the decay value
    
    def warm_func(t):
        decay = global_decay(t)
        max_lr_ = max_lr*decay
        base_lr_ = base_lr*decay
        return (max_lr_-base_lr_)/warm_step*(t%period) + base_lr_
    
    def decay_func(t):
        decay = global_decay(t)
        max_lr_ = max_lr*decay
        base_lr_ = base_lr*decay
        return (max_lr_-base_lr_)*np.cos(0.5*np.pi*((t%period)-warm_step)/(period-1-warm_step)) + base_lr_
 
    return lambda t: np.where((t%period)<warm_step, warm_func(t), decay_func(t))
 
def func_scheduler(optimizer, func):
    """
    Learning Rate Scheduler
    """
    return LambdaLR(optimizer, (lambda step: func(step)))


class BatchIndex:
    def __init__(self, size, batch_size, shuffle=False, drop_last=True):
        if drop_last:
            self.index_list = [(x, x + batch_size,) for x in range(size) if
                               not x % batch_size and x + batch_size <= size]
        else:
            li = [(x, x + batch_size,) for x in range(size) if not x % batch_size]
            x, y = li[-1]
            li[-1] = (x, size)
            self.index_list = li
            self.shuffle = shuffle
            self.drop_last = drop_last

        if shuffle:
            import random as r
            r.shuffle(self.index_list)

    def __next__(self):
        self.pos += 1
        if self.pos >= len(self.index_list):
            raise StopIteration

        return self.index_list[self.pos]

    def __iter__(self):
        self.pos = -1
        return self

    def __len__(self):
        return len(self.index_list)


device = torch.device("cuda:3" if torch.cuda.is_available() else "cpu")
print(device)

data_1 = np.loadtxt(prefix+'data_input.txt')
#print("min and max of data_1:")
#print(np.min(np.abs(data_1)))
#print(np.max(np.abs(data_1)))
print("mean of abs data_1:")
inputave = np.mean(np.abs(data_1))
print(inputave)
#data_1 /= inputave

data_2 = np.loadtxt(prefix+'data_output.txt')
#print("min and max of data_2:")
#print(np.min(np.abs(data_2)))
#print(np.max(np.abs(data_2)))
print("mean of abs data_2:")
outputave = np.mean(np.abs(data_2))
print(outputave)
data_2 /= outputave

class NNElement(nn.Module):
    def __init__(self, device, K0, input_dim, output_dim, hidden_dim, L1_num, L2_num):
        super().__init__()

        self.K = torch.from_numpy(K0).float().to(device)

        self.Li = nn.Linear(input_dim, hidden_dim)

        self.L1 = torch.nn.ModuleList([])
        for i in range(L1_num):
            self.L1.append(nn.Linear(hidden_dim, hidden_dim))
            self.L1.append(nn.LeakyReLU(0.01))

        self.L2 = torch.nn.ModuleList([])
        for i in range(L2_num):
            self.L2.append(nn.Linear(hidden_dim, hidden_dim))
            self.L2.append(nn.Tanh())

        self.Lo = nn.Linear(hidden_dim, output_dim)

        for m in self.L1:
            if isinstance(m, nn.Linear):
                #nn.init.kaiming_uniform_(m.weight, nonlinearity='relu')
                nn.init.kaiming_normal_(m.weight, nonlinearity='relu')
                m.bias.data.zero_()

        for m in self.L2:
            if isinstance(m, nn.Linear):
                #nn.init.xavier_uniform_(m.weight, gain=nn.init.calculate_gain('tanh'))
                nn.init.xavier_normal_(m.weight, gain=nn.init.calculate_gain('tanh'))
                m.bias.data.zero_()
        
    def forward(self, x):
        y = self.Li(x)

        for layer in self.L1:
            y = layer(y)

        x = torch.matmul(x, self.K)
        y = torch.mul(y, x)

        for layer in self.L2:
            y = layer(y)

        out = self.Lo(y)
        return out

xdata = torch.from_numpy(data_1).float()
ydata = torch.from_numpy(data_2).float()
xdata, ydata = xdata.to(device), ydata.to(device)


K0 = np.eye(8)*1.0/3.0
K0[0, 2] = -1.0/12.0
K0[0, 5] = -1.0/12.0
K0[0, 6] = -1.0/12.0
K0[0, 7] = -1.0/12.0
K0[1, 3] = -1.0/12.0
K0[1, 4] = -1.0/12.0
K0[1, 6] = -1.0/12.0
K0[1, 7] = -1.0/12.0
K0[2, 0] = -1.0/12.0
K0[2, 4] = -1.0/12.0
K0[2, 5] = -1.0/12.0
K0[2, 7] = -1.0/12.0
K0[3, 1] = -1.0/12.0
K0[3, 4] = -1.0/12.0
K0[3, 5] = -1.0/12.0
K0[3, 6] = -1.0/12.0
K0[4, 1] = -1.0/12.0
K0[4, 2] = -1.0/12.0
K0[4, 3] = -1.0/12.0
K0[4, 6] = -1.0/12.0
K0[5, 0] = -1.0/12.0
K0[5, 2] = -1.0/12.0
K0[5, 3] = -1.0/12.0
K0[5, 7] = -1.0/12.0
K0[6, 0] = -1.0/12.0
K0[6, 1] = -1.0/12.0
K0[6, 3] = -1.0/12.0
K0[6, 4] = -1.0/12.0
K0[7, 0] = -1.0/12.0
K0[7, 1] = -1.0/12.0
K0[7, 2] = -1.0/12.0
K0[7, 5] = -1.0/12.0

model1 = NNElement(device, K0, input_dim=8, output_dim=8, hidden_dim=8, L1_num=2, L2_num=2).to(device)
#model1.load_state_dict(torch.load(prefix+'trained_matrix_d2f.pth'))

#if torch.cuda.device_count() > 1:
#  print("Let's use", torch.cuda.device_count(), device)
#  model1 = nn.DataParallel(model1)

lr0 = 1e-3
lrx = 1e-3
nepochs = 1000000
decayrate = np.exp(np.log(lrx/lr0)/nepochs)

optimizer = optim.Adam(model1.parameters(), lr=1.0e-3)#, weight_decay=1e-7)
#scheduler = optim.lr_scheduler.MultiStepLR(optimizer, milestones=[50000, 150000, 200000], gamma=0.1)
scheduler = optim.lr_scheduler.ExponentialLR(optimizer, gamma=decayrate)

'''
base_lr = 1e-5
max_lr = 1e-2
warm_step = 100
period = 100000
total_cycle = 10
decay = 1e-2
nepochs = period*total_cycle

scheduler = func_scheduler(
    optimizer, circle_warmup_cosinedecay(base_lr=base_lr, max_lr=max_lr, warm_step=warm_step, period=period, decay=decay, total_cycle=total_cycle)
)
'''

loss_fn = nn.MSELoss()
#loss_fn = nn.L1Loss()

for epoch in range(nepochs):
    lossave = 0
    nindx = 0
    for ind1, ind2 in BatchIndex(200000, 10000, True):
        x = xdata[ind1:ind2]
        y = ydata[ind1:ind2]
        y_ = model1(x)
        loss = loss_fn(y_, y)
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
        lossave += loss.item()
        nindx += 1
    lossave /= nindx
    if epoch==0 or (epoch+1)%1000==0:
    	print((epoch+1), lossave)
    if (epoch+1)%1000 == 0:
    	#torch.save(model1.module.state_dict(), prefix+'trained_matrix_d2f.pth')
    	torch.save(model1.state_dict(), prefix+'trained_matrix_d2f.pth')
    scheduler.step()
