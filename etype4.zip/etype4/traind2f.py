import numpy as np
import torch.multiprocessing as mp
import torch
from torch import nn
from torch import optim
import torch.utils.data as Data
from torch.optim.lr_scheduler import LambdaLR


def circle_warmup_cosinedecay(base_lr, max_lr, warm_step=500, period=5000, decay=0.01, total_cycle=None):
    """
    Circle Warmup Cosine Decay Scheduler
    """
    def global_decay(t):
        return 1.0 - (1.0-decay)*(np.int(t/period)/(total_cycle-1)) # decay from 1.0 to the decay value
    
    def warm_func(t):
        decay = global_decay(t)
        max_lr_ = max_lr*decay
        base_lr_ = base_lr*decay
        return (max_lr_-base_lr_)/warm_step*(t%period) + base_lr_
    
    def decay_func(t):
        decay = global_decay(t)
        max_lr_ = max_lr*decay
        base_lr_ = base_lr*decay
        return (max_lr_-base_lr_)*np.cos(0.5*np.pi*((t%period)-warm_step)/(period-1-warm_step)) + base_lr_
 
    return lambda t: np.where((t%period)<warm_step, warm_func(t), decay_func(t))
 
def func_scheduler(optimizer, func):
    """
    Learning Rate Scheduler
    """
    return LambdaLR(optimizer, (lambda step: func(step)))
 


prefix='./'


device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(device)

data_1 = np.loadtxt(prefix+'data_input.txt')
#print("min and max of data_1:")
#print(np.min(np.abs(data_1)))
#print(np.max(np.abs(data_1)))
print("mean of abs data_1:")
inputave = np.mean(np.abs(data_1))
print(inputave)
#data_1 /= inputave

data_2 = np.loadtxt(prefix+'data_output.txt')
#print("min and max of data_2:")
#print(np.min(np.abs(data_2)))
#print(np.max(np.abs(data_2)))
print("mean of abs data_2:")
outputave = np.mean(np.abs(data_2))
print(outputave)
data_2 /= outputave

class NNElement(nn.Module):
    def __init__(self, device, K0):
        super().__init__()

        self.K = torch.from_numpy(K0).float().to(device)

        self.L1 = nn.Linear(8, 8)
        self.L2 = nn.Tanh()
        self.L3 = nn.Linear(8, 8)
        self.L4 = nn.Tanh()

        self.L5 = nn.Linear(8, 8)
        self.L6 = nn.Tanh()
        self.L7 = nn.Linear(8, 8)
        self.L8 = nn.Tanh()

        #self.L9 = nn.Linear(16, 8)
        #self.L10 = nn.Tanh()

        #self.L11 = nn.Linear(16, 8)
        #self.L12 = nn.Tanh()

        self.Lo = nn.Linear(8, 8)
        
    def forward(self, x):
        y1 = self.L1(x)
        y2 = self.L2(y1)
        y3 = self.L3(y2)
        y4 = self.L4(y3)
        
        z0 = torch.matmul(x, self.K)
        z = torch.mul(y4, z0)
        y5 = self.L5(z)
        y6 = self.L6(y5)
        y7 = self.L7(y6)
        y8 = self.L8(y7)
        
        #z = torch.cat((y8,x), 1)
        #y9 = self.L9(z)
        #y10 = self.L10(y9)
        #
        #z = torch.cat((y10,x), 1)
        #y11 = self.L11(z)
        #y12 = self.L12(y11)
        
        out = self.Lo(y8)
        return out

x = torch.from_numpy(data_1).float()
y = torch.from_numpy(data_2).float()
x, y = x.to(device), y.to(device)


K0 = np.eye(8)*1.0/3.0
K0[0, 2] = -1.0/12.0
K0[0, 5] = -1.0/12.0
K0[0, 6] = -1.0/12.0
K0[0, 7] = -1.0/12.0
K0[1, 3] = -1.0/12.0
K0[1, 4] = -1.0/12.0
K0[1, 6] = -1.0/12.0
K0[1, 7] = -1.0/12.0
K0[2, 0] = -1.0/12.0
K0[2, 4] = -1.0/12.0
K0[2, 5] = -1.0/12.0
K0[2, 7] = -1.0/12.0
K0[3, 1] = -1.0/12.0
K0[3, 4] = -1.0/12.0
K0[3, 5] = -1.0/12.0
K0[3, 6] = -1.0/12.0
K0[4, 1] = -1.0/12.0
K0[4, 2] = -1.0/12.0
K0[4, 3] = -1.0/12.0
K0[4, 6] = -1.0/12.0
K0[5, 0] = -1.0/12.0
K0[5, 2] = -1.0/12.0
K0[5, 3] = -1.0/12.0
K0[5, 7] = -1.0/12.0
K0[6, 0] = -1.0/12.0
K0[6, 1] = -1.0/12.0
K0[6, 3] = -1.0/12.0
K0[6, 4] = -1.0/12.0
K0[7, 0] = -1.0/12.0
K0[7, 1] = -1.0/12.0
K0[7, 2] = -1.0/12.0
K0[7, 5] = -1.0/12.0
model1 = NNElement(device, K0).to(device)
model1.load_state_dict(torch.load(prefix+'trained_matrix_d2f.pth'))

#if torch.cuda.device_count() > 1:
#  print("Let's use", torch.cuda.device_count(), device)
#  model1 = nn.DataParallel(model1)

#lr0 = 1e-2
#lrx = 1e-5
#nepochs = 1000000
#decayrate = np.exp(np.log(lrx/lr0)/nepochs)

optimizer = optim.Adam(model1.parameters(), lr=1.0)#, weight_decay=1e-7)
#scheduler = optim.lr_scheduler.MultiStepLR(optimizer, milestones=[50000, 150000, 200000], gamma=0.1)
#scheduler = optim.lr_scheduler.ExponentialLR(optimizer, gamma=decayrate)

base_lr = 1e-5
max_lr = 1e-4
warm_step = 100
period = 100000
total_cycle = 10
decay = 1e-2
nepochs = period*total_cycle

scheduler = func_scheduler(
    optimizer, circle_warmup_cosinedecay(base_lr=base_lr, max_lr=max_lr, warm_step=warm_step, period=period, decay=decay, total_cycle=total_cycle)
)

#loss_fn = nn.MSELoss()
loss_fn = nn.L1Loss()

for epoch in range(nepochs):
	y_ = model1(x)
	loss = loss_fn(y_, y)
	loss.backward()
	optimizer.step()
	optimizer.zero_grad()
	if epoch==0 or (epoch+1)%1000==0:
		print((epoch+1), loss.item())
	if (epoch+1)%1000 == 0:
		#torch.save(model1.module.state_dict(), prefix+'trained_matrix_d2f.pth')
		torch.save(model1.state_dict(), prefix+'trained_matrix_d2f.pth')
	scheduler.step()
